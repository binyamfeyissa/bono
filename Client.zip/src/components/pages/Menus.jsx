import React from "react";
import { Link } from "react-router-dom";
import MenusItem from "../MenusItem";
function Menus() {
  return (
    <div>
      <MenusItem />
    </div>
  );
}

export default Menus;
