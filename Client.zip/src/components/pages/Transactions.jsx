import React from "react";

function Transactions() {
  return <div>Transactions</div>;
}

export default Transactions;
