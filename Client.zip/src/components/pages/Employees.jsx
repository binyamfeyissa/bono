import React from "react";

function Employees() {
  return <div>Employees</div>;
}

export default Employees;
