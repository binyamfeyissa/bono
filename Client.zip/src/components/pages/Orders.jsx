import React from "react";
import OrdersItem from "../OrdersItem";

function Orders() {
  return <OrdersItem></OrdersItem>;
}

export default Orders;
