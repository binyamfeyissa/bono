import React from "react";

function Users() {
  return <div>Users</div>;
}

export default Users;
